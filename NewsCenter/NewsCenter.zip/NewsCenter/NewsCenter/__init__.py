"""
	Package for NewsCenter.
"""
