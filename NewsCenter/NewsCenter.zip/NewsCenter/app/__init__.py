"""
	Package for the application.
"""
