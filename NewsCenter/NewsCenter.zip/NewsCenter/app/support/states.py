
PROFILE_BANNED = 'zbanowany'
PROFILE_USER   = 'użytkownik'
PROFILE_MOD    = 'moderator'
PROFILE_ADMIN  = 'administrator'
